Remove Express dependency from Node.js example.

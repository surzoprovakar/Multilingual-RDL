#!/usr/bin/env bash

#ensure death
killall node

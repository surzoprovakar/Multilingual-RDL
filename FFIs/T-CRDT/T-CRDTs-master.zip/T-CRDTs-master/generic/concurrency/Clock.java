package generic.concurrency;

public interface Clock extends Comparable<Clock> {

}
